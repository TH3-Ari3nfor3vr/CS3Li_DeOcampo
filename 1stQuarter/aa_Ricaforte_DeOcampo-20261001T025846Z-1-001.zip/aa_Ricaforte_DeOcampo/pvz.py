
class Plant:
    def __init__(self, name, health, damage):
        self.name = name
        self.health = health
        self.damage = damage

    def attack(self, zombie):
        if self.health > 0:
            print(f" {self.name} attacks {zombie.name} for {self.damage} damage!")
            zombie.take_damage(self.damage)

    def take_damage(self, amount):
        self.health -= amount
        if self.health < 0:
            self.health = 0
        print(f" {self.name} took {amount} damage! [Remaining HP: {self.health}]")
        if self.health == 0:
            print(f" {self.name} has been defeated!")


class Zombie:
    def __init__(self, name, health, damage, distance):
        self.name = name
        self.health = health
        self.damage = damage
        self.distance = distance

    def move(self):
        if self.distance > 0:
            self.distance -= 1
            print(f" {self.name} moves 1 step closer. [Current Distance: {self.distance}]")

    def attack(self, plant):
        print(f" {self.name} bites {plant.name} for {self.damage} damage!")
        plant.take_damage(self.damage)

    def take_damage(self, amount):
        self.health -= amount
        if self.health < 0:
            self.health = 0
        print(f" {self.name} took {amount} damage! [Remaining HP: {self.health}]")
        if self.health == 0:
            print(f" {self.name} died!")


if __name__ == "__main__":
    print("Mini Plants vs Zombies")
    
    plant1 = Plant("Peashooter", health=100, damage=15)
    plant2 = Plant("Snow Pea", health=100, damage=10)
    zombie = Zombie("Regular Zombie", health=100, damage=10, distance=3)
    
    turn = 1
    
    while zombie.health > 0 and (plant1.health > 0 or plant2.health > 0):
        print(f"\nTURN {turn}")
        
        if plant1.health > 0:
            plant1.attack(zombie)
            if zombie.health <= 0:
                break
                
        if plant2.health > 0:
            plant2.attack(zombie)
            if zombie.health <= 0:
                break
                
        if zombie.distance > 0:
            zombie.move()
        else:
            if plant1.health > 0:
                zombie.attack(plant1)
            elif plant2.health > 0:
                zombie.attack(plant2)
                
        print(f"[Status] {plant1.name}: {plant1.health} HP | {plant2.name}: {plant2.health} HP | {zombie.name}: {zombie.health} HP | Distance: {zombie.distance}")
        turn += 1

    if zombie.health <= 0:
        print(" GAME OVER | THE PLANTS DEFENDED THE LAWN!")
    else:
        print(" GAME OVER | THE ZOMBIES ATE YOUR BRAINS!")
